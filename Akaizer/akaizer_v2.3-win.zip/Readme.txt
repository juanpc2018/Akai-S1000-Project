Akaizer v2.3 for Windows
+--------------------------------------------------+
|    _____   __            __                      |
|   /  _  \ |  | _______  |__|_______ ___________  |
|  /  /_\  \|  |/ /\__  \ |  \___   // __ \_  __ \ |
| /    |    \    <  / __ \|  |/    /\  ___/|  | \/ |
| \____|__  /__|_ \(____  /__/_____ \\___  >__|    |
|         \/     \/     \/         \/    \/        |
|                                                  |
+--------------------------------------------------+

+-------+
| ABOUT |
+-------+
Akaizer is a freeware application for Windows / macOS / Linux which can time stretch (and/or pitch shift) any WAVE or AIFF sound file in the style of the 'cyclic' time stretch which featured on old Akai sound samplers, like the S950 / S1000 / S2000 / S3000 series. This is ideal for DAW-based music producers who want that classic metallic-sounding effect, as used in many old school Hardcore / Jungle / Speed Garage tunes from the 1990s, without the need for an actual Akai sampler.

http://the-akaizer-project.blogspot.com/

+---------------------+
| SYSTEM REQUIREMENTS |
+---------------------+
Windows XP/Vista/7/8/10
Optional: Sound card.

+---------------+
| TIPS ON USAGE |
+---------------+
* There are two time stretch algorithms: CLASSIC simulates the Akai cyclic time stretch as faithfully as possible, with perfect pitch but with minor quirks like bad timing. REVISED improves on the classic algorithm with perfect timing and a fuller sound but with the minor compromise of the pitch drifting ever so slightly away from its true key with some settings. The REVISED algorithm is basically the same one as used in previous 1.x versions of Akaizer.

* 50% time factor will halve the length of a sound, 100% is normal length, 200% will double the length... and so on. This should ideally be set to the default value of 100 when pitch shifting only.

* +12 transpose will pitch shift the sound upwards by 12 semitones (1 octave), +24 by 24 semitones (2 octaves), -8 will pitch shift downwards by 8 semitones... and so on. This should ideally be set to the default value of 0 when time stretching only.

* Decrease the cycle length value to get a more 'metallic' effect and vice versa.

* Read the tooltips when hovering over buttons etc, as they give extra info.

+--------------------+
| KEYBOARD SHORTCUTS |
+--------------------+
Alt+E     = Open WAVE or AIFF file
Alt+R     = Select 'revised' algorithm
Alt+C     = Select 'classic' algorithm
Alt+1     = Edit time factor value
Alt+2     = Edit cycle length value
Alt+3     = Edit transpose value
Alt+4     = Reset time factor to default value
Alt+5     = Reset cycle length to default value
Alt+6     = Reset transpose to default value
Alt+L     = Play opened file
Alt+T     = Stop playing
Alt+O     = Toggle playback looping on/off
Alt+P     = Preview processed sound
Alt+S     = Save processed sound to new file
Alt+F4    = Quit
Tab       = Cycles through each control
Shift+Tab = Cycles through each control but in the reverse direction

+-----------------+
| RELEASE HISTORY |
+-----------------+
v2.3 released October 2017
v2.2.2 released September 2017
v2.2.1 released January 2013
v2.2 released May 2012
v2.1.1 released April 2012
v2.1 released January 2012
v2.0.1 released October 2011
v2.0 released October 2011
v1.12 released May 2011
v1.11 released April 2011
v1.10 released March 2011
v1.9 released January 2011
v1.8.2 released December 2010
v1.8.1 released November 2010
v1.8 released August 2010
v1.7.2 released July 2010
v1.7.1 released June 2010
v1.7 released March 2010
v1.6 released February 2010
v1.5.1 released January 2010
v1.5 released January 2010
v1.4 released November 2009
v1.3.1 released May 2009
v1.3 released May 2009
v1.2 released December 2005
v1.1 released November 2005
v1.0 released January 2005

Read Changelog.txt for more detailed info.
