Akaizer [CLI Edition] v2.2 for Windows / macOS / Linux
+--------------------------------------------------+
|    _____   __            __                      |
|   /  _  \ |  | _______  |__|_______ ___________  |
|  /  /_\  \|  |/ /\__  \ |  \___   // __ \_  __ \ |
| /    |    \    <  / __ \|  |/    /\  ___/|  | \/ |
| \____|__  /__|_ \(____  /__/_____ \\___  >__|    |
|         \/     \/     \/         \/    \/        |
|                                                  |
+--------------------------------------------------+

+-------+
| ABOUT |
+-------+
Akaizer is a freeware application for Windows / macOS / Linux which can time stretch (and/or pitch shift) any WAVE or AIFF sound file in the style of the 'cyclic' time stretch which featured on old Akai sound samplers, like the S950 / S1000 / S2000 / S3000 series. This is ideal for DAW-based music producers who want that classic metallic-sounding effect, as used in many old school Hardcore / Jungle / Speed Garage tunes from the 1990s, without the need for an actual Akai sampler.

http://the-akaizer-project.blogspot.com/

+---------------------+
| SYSTEM REQUIREMENTS |
+---------------------+
Windows: XP/Vista/7/8/10
macOS: Mac OS X 10.3 (Panther) or higher on PowerPC or Intel platform.
Linux: Any Linux distribution.
Optional: Sound card.

+-------+
| USAGE |
+-------+
Akaizer [CLI Edition] is run from the command line interface with the following syntax:

akaizer <file> <time factor> <cycle length> <transpose> [-c] [-l] [-p]

NOTE: You may have to replace the command 'akaizer' with the full path to the application, depending on the location you have the terminal currently set to. Simply drag and drop the Akaizer executable file on to the terminal window and it will add the path for you. All you need to do then is input the rest of the required parameters. Parameters enclosed with [ ] are optional and parameters enclosed with < > are required.

<file> = Full path to source WAVE/AIFF file. You can drag and drop the source file to the terminal window and the path will be added for you.

<time factor> = Value between 25 to 2000 percent. 50 will halve the length of a sound, 100 is normal length, 200 will double the length... and so on. Values to 2 decimal places (e.g. 207.59) may also be used (only when using the default 'revised' cyclic algorithm!) if extra precision is required. This should ideally be set to the default value of 100 when pitch shifting only.

<cycle length> = Value between 20 to 2000 samples. Decrease the value to get a more 'metallic' effect and vice versa. 1000 is a good central starting point.

<transpose> = Value between -24 to +24 semitones. 12 will pitch shift the sound upwards by 12 semitones (1 octave), 24 by 24 semitones (2 octaves), -8 will pitch shift downwards by 8 semitones... and so on. This should ideally be set to the default value of 0 when time stretching only.

[-c] = Enable 'classic' cyclic algorithm. The 'revised' cyclic algorithm is automatically used as the default algorithm when this parameter is excluded. 'Classic' simulates the Akai cyclic time stretch as faithfully as possible, with perfect pitch but with minor quirks like bad timing. 'Revised' improves on the 'classic' algorithm with perfect timing and a fuller sound but with the minor compromise of the pitch drifting ever so slightly away from its true key with some settings. The 'revised' algorithm is basically the same one as used in previous 1.x versions of Akaizer.

[-l] = Enable looping in preview mode. Use this to loop playback of the processed sound when previewing. This is handy for breakbeats, for example.

[-p] = Enable preview mode. Use this to hear what the processed sound will sound like. If you exclude this parameter then the processed sound will be saved as a new file, in the same location as the source sound file, with the settings values appended after the file name.

The optional [-c], [-l] and [-p] parameters can be used in any order after the required <file>, <time factor>, <cycle length> and <transpose> parameters.

+----------+
| EXAMPLES |
+----------+
Time Stretching with 'classic' cyclic algorithm:

akaizer test123.wav 200 1000 0 -c

- This will time stretch the file 'test123.wav' by 200% with a cycle length of 1000 samples. Note that <transpose> is set to 0 and [-c] is also included to enable the 'classic' cyclic algorithm.

Pitch Shifting with 'revised' cyclic algorithm:

akaizer test123.wav 100 750 -9

- This will pitch shift the file 'test123.wav' downwards by 9 semitones with a cycle length of 750 samples. Note that <time factor> is set to 100 and [-c] has been excluded to use the default 'revised' cyclic algorithm.

Time Stretching + Pitch Shifting:

akaizer test123.wav 79.59 691 4

- This will time stretch the file 'test123.wav' by 79.59% and simultaneously pitch shift upwards by 4 semitones with a cycle length of 691 samples, using the default 'revised' cyclic algorithm.

Previewing:

akaizer test123.wav 400 2000 0 -p

- This will preview the file 'test123.wav' time stretched by 400% with a cycle length of 2000 samples, using the default 'revised' cyclic algorithm. Note that [-p] is included to enable the preview mode.

Previewing & Looping:

akaizer test123.wav 400 2000 0 -c -p -l

- This will preview the file 'test123.wav' time stretched by 400% with a cycle length of 2000 samples, using the 'classic' cyclic algorithm. Note that [-p] is included to enable the preview mode and [-l] is also included to enable looping.

+-----------------+
| RELEASE HISTORY |
+-----------------+
v2.2 released October 2017
v2.1.2 released January 2013
v2.1.1 released May 2012
v2.1 released February 2012
v1.6 released May 2011
v1.5 released April 2011
v1.4 released January 2011
v1.3.3 released December 2010
v1.3.2 released November 2010
v1.3.1 released September 2010
v1.3 released August 2010
v1.2 released March 2010
v1.1 released February 2010
v1.0 released November 2009

Read Changelog.txt for more detailed info.
