Subject: Copying operating system files to floppy disk

The operating system file included is an executable file that is only supported in PC
compatible computers. To copy the OS file to floppy, double-click on the file and 
follow the on-screen directions.

To Update the sampler:
Insert the floppy disk into the floppy drive and turn the samplers power on. 
There is no way to permenantly update the sampler from floppy disk, so this must be
done each time you power up the sampler. If you would like to permenantly install the
update you must contact an authorized sevice facility to replace the OS EPROM 
installed in the sampler.
